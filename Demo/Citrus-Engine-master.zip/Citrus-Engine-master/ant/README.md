Build instructions
------------------

The ant is configured to be built on a PC or a Mac.

*The instructions below aren't useful anymore. The ant manages everything now.*

Before running the script, you must generate the comments for the ASDoc using [ASDocr](http://gskinner.com/blog/archives/2010/05/asdocr_update_f_1.html).

Take a look on the screenshot to know how to configure it:


![ScreenShot](http://aymericlamboley.fr/blog/wp-content/uploads/2013/06/Capture0.PNG)
![ScreenShot](http://aymericlamboley.fr/blog/wp-content/uploads/2013/06/Capture1.PNG)
![ScreenShot](http://aymericlamboley.fr/blog/wp-content/uploads/2013/06/Capture2.PNG)
![ScreenShot](http://aymericlamboley.fr/blog/wp-content/uploads/2013/06/Capture3.PNG)

Now you can run it! When it's done, you will be enable to run the ant script.

If you want to generate the ASDoc in a html format, remove the additional params from the last screenshot picture.
