Thoses are the same assets than in bin/multi-resolutions/.
They are used here to generate the tilesets. Be sure to name each tile with their xml's name.
This spritesheet is never loaded.