robotlegs2 samples
----

These are some samples for robotlegs 2.

# timer-mvcbundle

A simple sample use the mvc bundle.

# timer-extension

A simple sample only use some extensions.


