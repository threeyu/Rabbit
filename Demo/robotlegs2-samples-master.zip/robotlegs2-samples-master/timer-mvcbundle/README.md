## Introduce

This a sample for robotlegs2 with MVCBundle.

## Dependence

* robotlegs 2.0.0.b6
* minimalcomps 0.9.11
